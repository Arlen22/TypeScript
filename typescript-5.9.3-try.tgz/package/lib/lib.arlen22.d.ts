/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */


/// <reference no-default-lib="true"/>

/////////////////////////////
/// Arlen22 Fork Additions
/////////////////////////////

interface SymbolConstructor { readonly iterableIndex: unique symbol; }
interface IndexedIterable<T extends { [x: number]: any }> {
  [Symbol.iterator]: () => Iterator<T[number]>
  [Symbol.iterableIndex]: T;
}

interface TryResultErrorObject {
  ok: false; error: Error; value: undefined;
  [Symbol.iterator]: () => Iterator<any>;
  [Symbol.iterableIndex]: {
    0: false, 1: Error, 2: undefined
  }
}

interface TryResultValueObject<V> {
  ok: true; error: undefined; value: V;
  [Symbol.iterator]: () => Iterator<any>;
  [Symbol.iterableIndex]: {
    0: true, 1: undefined, 2: V
  }
}

type TryResult<V> = TryResultErrorObject | TryResultValueObject<V>

interface ResultConstructor {
  /**
   * Creates a result for a successful operation
   */
  ok<V>(value: V): TryResult<V>

  /**
   * Creates a result for a failed operation
   */
  error<V>(error: unknown): TryResult<V>
}

declare const TryResult: ResultConstructor
